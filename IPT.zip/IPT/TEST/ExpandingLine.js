   /* globals Raphael */
   Raphael.fn.line = function () {
     var padding = 0;
     var margin = 0.85;
     var line = this.path('M0,' + (this.height * (1 - margin)) + ', L' + this.width + ',' + (this.height * (1 - margin)) + 'H');
     for (let i = 24; i > 0; i = i - 1) {
      var hourWidth = ((this.width * i) / 24);
      var hourlineIN = this.path('M' + (hourWidth + padding) + ',' + (this.height * (1 - margin)) + ', L' + (hourWidth + padding) + ',' + (this.height - 600) + 'V');
     }
     
     
     var e1 = this.ellipse(this.width, 100, 40, 40).attr({ fill: "red" });
     
     $(e1.node).bind('mousewheel', function (event) {
         line.attr({ path : 'M0,' + 50 + ', L' + 100 + ',' + 50 + 'H',  "stroke": "#777"});
         
         event.preventDefault();
      });
     
     return line;
   }