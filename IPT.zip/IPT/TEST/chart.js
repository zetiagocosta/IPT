


window.onload = function () {
        
        
    var paper = new Raphael("myChart", screen.width, screen.height);
    line = paper.line();
  }