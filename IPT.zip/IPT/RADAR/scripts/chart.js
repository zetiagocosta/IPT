var radar = {
    data: {
      max: 50,
      scores: [[30, 30, 30, 30, 30]],
      labels: ["STR", "VIT", "LCK", "INT", "DEX"]
    },
    size: {
      width: 250,
      height: 275
    },
    style: {
      bg: {"gradient": "270-#fff-#fff:270-#ddd", "stroke-width": "0"},
      polygon: {"stroke": "#555", "stroke-width": "3"},
      scores: [{"fill": "#f90", "fill-opacity": "0.8",
                "stroke-width": "2", "stroke": "#a64"}],
      circle: {'fill': '#888','stroke-width': '0'},
      axis: ["stroke", "#777"],
      label: {'fill': "#555"}
    },
    chart: null
  };
  window.onload = function () {
    radar.chart = Raphael("myChart", radar.size.width, radar.size.height);
    radar.chart.rect(0, 0, radar.size.width, radar.size.height, 0).attr(radar.style.bg);
    radar.chart.radarchart(radar.data, radar.size, radar.style);
  }

