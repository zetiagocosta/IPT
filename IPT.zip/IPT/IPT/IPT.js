
window.onload = function () {

  var paperSATL = new Raphael(document.getElementById('sistema_SATL'), screen.width / 16, screen.height / 4);
  var rectSATL = paperSATL.rect(0, 0, paperSATL.width, paperSATL.height).attr({ fill: "#65FF00", stroke: "black", "stroke-width": "3px" });
  var textSATL = paperSATL.text(paperSATL.width / 2, paperSATL.height / 2, "SATL/\nLINUX/\nOPER-B").attr({ "font-size": "12px", "font-weight": "100", stroke: "black", "stroke-width": "1px" });

  var paperSATL_LIS = new Raphael(document.getElementById('sistema_SATL_LIS'), screen.width / 22, screen.height / 20);
  var rectSATL_LIS = paperSATL_LIS.rect(0, 0, paperSATL_LIS.width, paperSATL_LIS.height).attr({ fill: "#65FF00", stroke: "black", "stroke-width": "3px" });
  var textSATL_LIS = paperSATL_LIS.text(paperSATL_LIS.width / 2, paperSATL_LIS.height / 2, "LIS").attr({ "font-size": "12px", "font-weight": "100", stroke: "black", "stroke-width": "1px" });

  //Aplicar uma margem de 10%
  var margin = 0.85;

  var g = new Raphael(document.getElementById('sistema_SATL_LIS_GRAPH'), screen.width / 1.20, screen.height / 20);
  var graph = g.set();

  var topline = g.path('M0,' + (g.height * (1 - margin)) + ', L' + g.width + ',' + (g.height * (1 - margin)) + 'H');
  graph.push(topline);
  var downline = g.path('M0,' + (g.height * margin) + ', L' + g.width + ',' + (g.height * margin) + 'H');
  graph.push(downline);

  var middle = g.height / 3;
  var verticaltimeline = 50;

  //var canal = g.rect(0, (g.height - verticaltimeline + 4), g.width, 20).attr({ fill: "#D3D3D3", "stroke-width": 0 });


  function drawBase(padding = 0) {
    for (let i = 24; i > 0; i = i - 1) {
      var hourWidth = ((g.width * i) / 24);
      var hourlineIN = g.path('M' + (hourWidth + padding) + ',' + (g.height * (1 - margin)) + ', L' + (hourWidth + padding) + ',' + (g.height - verticaltimeline) + 'V');
      graph.push(hourlineIN);
      var hourlineOUT = g.path('M' + (hourWidth) + ',' + (g.height * (margin)) + ', L' + (hourWidth) + ',' + verticaltimeline + 'V');
      graph.push(hourlineOUT);
      var texthour = g.text(hourWidth, middle + 11, +(i < 10) ? '0' + i + "H" : i + "H").attr({ "font-size": "10px" });
      graph.push(texthour);
    }
  }

  drawBase(0);

  function draw() {
    graph.forEach(function (el) { el.toFront() });
    if (index > 0) {
      var width = changeWidth();
      g.getById(rects[index - 1]).attr({ width: width });
    }
    index++;
    //console.log(index);
  }

  var e1 = paperSATL.ellipse(100, 100, 40, 40).attr({ fill: "red" });
  $(e1.node).bind('mousewheel', function (event) {
    e1.attr({ rx: e1.attr("rx") + 2 });
    //drawBase(2);
    event.preventDefault();
  });

  function changeWidth() {
    return g.getById(rects[index]).attr('x') - g.getById(rects[index - 1]).attr('x');
  }

  let msgs = [
    [291493177, 1703128328, "IPT-RSA-RELAY-8500", "IN", 7, ""],
    [291493177, 1703128498, "IPT-RSA-RELAY-8500", "IN", 7, ""],
    [291493177, 1703128598, "IPT-RSA-RELAY-8500", "IN", 7, "txt"],
    [291493177, 1703128698, "IPT-RSA-RELAY-8500", "IN", 7, ""],
    [291493177, 1703129698, "IPT-RSA-RELAY-8500", "IN", 7, ""],
    [291493177, 1703130698, "IPT-RSA-RELAY-8500", "IN", 7, ""],
    [291493177, 1703128328, "IPT-RSA-RELAY-8500", "OUT", 7, "txt"],
    [291493177, 1703128498, "IPT-RSA-RELAY-8500", "OUT", 7, ""],
    [291493177, 1703128598, "IPT-RSA-RELAY-8500", "OUT", 7, ""],
    [291493177, 1703128698, "IPT-RSA-RELAY-8500", "OUT", 7, "txt"],
    [291493177, 1703129698, "IPT-RSA-RELAY-8500", "OUT", 7, "txt"],
    [291493177, 1703130698, "IPT-RSA-RELAY-8500", "IN", 7, ""],
    [291493177, 1703328338, "IPT-RSA-RELAY-8500", "IN", 7, ""],
    [291493177, 1703328358, "IPT-RSA-RELAY-8500", "IN", 7, ""],
    [291493179, 1703336428, "IPT-RSA-RELAY-8500", "OUT", 7, "txt"],
    [291493177, 1703334328, "IPT-RSA-RELAY-8500", "CLOSE", 7, ""],
    [291493179, 1703338428, "IPT-RSA-RELAY-8500", "OPEN", 7, "txt"],
    [291495975, 1703348128, "IPT-RSA-RELAY-8500", "IN", 122, ""],
    [291496061, 1703361414, "IPT-RSA-RELAY-8500", "OUT", 7, "txt"],
    [291498389, 1703352628, "IPT-RSA-RELAY-8500", "OUT", 7, "txt"],
    [291498491, 1703362578, "IPT-RSA-RELAY-8500", "IN", 7, ""],
    [291502025, 1703361268, "IPT-RSA-RELAY-8500", "END", 122, ""],
    [291502069, 1703364568, "IPT-RSA-RELAY-8500", "START", 282, ""],
    [291503197, 1703364868, "IPT-RSA-RELAY-8500", "OUT", 7, "txt"],
    [291503267, 1703365288, "IPT-RSA-RELAY-8500", "IN", 7, ""]];

  let rects = [];
  let index = 0;

  msgs.forEach(element => {

    var time = new Date(element[1] * 1000);
    //console.log(time);
    var hour = time.getUTCHours();
    var min = time.getUTCMinutes();
    var sec = time.getUTCSeconds();

    //convert to secs
    var timesec = hour * 3600 + min * 60 + sec;

    var x = ((g.width) * timesec) / 86400;
    var y = (g.height * (1 - margin));

    var circleOUT;
    var circleIN;

    {
      if (element[3] == 'IN') {
        if (element[5] != "") circleIN = g.circle(x, y, 5).attr({ "stroke": "black", "fill": "green" }).hover(function () { this.attr({ r: 7 }) }, function () { this.attr({ r: 5 }) });
        else
          circleIN = g.circle(x, y, 5).attr({ "stroke": "green", "fill": "white" })
            .hover(function () { this.attr({ r: 7 }) }, function () { this.attr({ r: 5 }) });
      }

      else
        if (element[3] == 'OUT') {
          if (element[5] != "") circleOUT = g.circle(x, (g.height * margin), 5).attr({ "stroke": "black", "fill": "green" }).hover(function () { this.attr({ r: 7 }) }, function () { this.attr({ r: 5 }) });
          else
            circleOUT = g.circle(x, (g.height * margin), 5).attr({ "stroke": "green", "fill": "white" })
              .hover(function () { this.attr({ r: 7 }) }, function () { this.attr({ r: 5 }) })
        }
        else
          //draw rectangles
          if (element[3] == 'CLOSE') {
            var canalClose = g.rect(x, (g.height - verticaltimeline + 4), g.width, 20).attr({ fill: "#D3D3D3", "stroke-width": 0 }).hover(function () { this.attr({ "stroke-width": 1 }) }, function () { this.attr({ "stroke-width": 0 }) });
            rects.push(canalClose.node.raphaelid);
            draw();
          }
          else
            if (element[3] == 'OPEN') {
              var canalOpen = g.rect(x, (g.height - verticaltimeline + 4), g.width, 20).attr({ fill: "#65FF00", "stroke-width": 0 }).hover(function () { this.attr({ "stroke-width": 1 }) }, function () { this.attr({ "stroke-width": 0 }) });;
              rects.push(canalOpen.node.raphaelid);
              draw();
            }
            else
              if (element[3] == 'START') {
                var canalStart = g.rect(x, (g.height - verticaltimeline + 4), g.width, 20).attr({ fill: "#D3D3D3", "stroke-width": 0 }).hover(function () { this.attr({ "stroke-width": 1 }) }, function () { this.attr({ "stroke-width": 0 }) });;
                rects.push(canalStart.node.raphaelid);
                draw();
              }
              else
                if (element[3] == 'END') {
                  var canalEnd = g.rect(x, (g.height - verticaltimeline + 4), g.width, 20).attr({ fill: "red", "stroke-width": 0 }).hover(function () { this.attr({ "stroke-width": 1 }) }, function () { this.attr({ "stroke-width": 0 }) });;
                  rects.push(canalEnd.node.raphaelid);
                  draw();
                }
    }

    //1 Day = 86400 in Epoch (24 Hours)
    //console.log("---------------------------");
  });


}

